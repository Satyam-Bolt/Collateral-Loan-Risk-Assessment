package com.cts.clra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RiskAssessmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
