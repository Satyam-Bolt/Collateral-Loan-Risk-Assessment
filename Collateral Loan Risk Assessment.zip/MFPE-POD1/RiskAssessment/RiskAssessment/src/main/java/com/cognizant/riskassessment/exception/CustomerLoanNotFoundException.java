package com.cognizant.riskassessment.exception;

public class CustomerLoanNotFoundException extends Exception{

	public CustomerLoanNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
