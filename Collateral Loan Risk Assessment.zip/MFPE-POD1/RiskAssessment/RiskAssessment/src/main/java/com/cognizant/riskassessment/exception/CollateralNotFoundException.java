package com.cognizant.riskassessment.exception;

public class CollateralNotFoundException extends Exception{

	public CollateralNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
