package com.cognizant.riskassessment.service;

import com.cognizant.riskassessment.exception.CollateralNotFoundException;
import com.cognizant.riskassessment.exception.CustomerLoanNotFoundException;
import com.cognizant.riskassessment.exception.DataNotPresentException;
import com.cognizant.riskassessment.model.CollateralRisk;

public interface RiskAssessmentService {

	CollateralRisk getRiskForRealEstate(String collateralType, int loanId) throws  CollateralNotFoundException, CustomerLoanNotFoundException;

	CollateralRisk getRiskForCashDeposits(String token, int loanId) throws  CollateralNotFoundException, CustomerLoanNotFoundException;

}