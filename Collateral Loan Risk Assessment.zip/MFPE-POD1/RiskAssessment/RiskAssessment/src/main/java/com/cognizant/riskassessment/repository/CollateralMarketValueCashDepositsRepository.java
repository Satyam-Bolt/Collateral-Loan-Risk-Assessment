package com.cognizant.riskassessment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.riskassessment.model.CollateralMarketValueCashDeposits;

public interface CollateralMarketValueCashDepositsRepository extends JpaRepository<CollateralMarketValueCashDeposits, Integer> {

	CollateralMarketValueCashDeposits findByBankName(String bankName);
}
