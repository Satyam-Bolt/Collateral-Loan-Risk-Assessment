package com.cognizant.riskassessment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.riskassessment.model.CollateralMarketValueRealEstate;


public interface CollateralMarketValueRealEstateRepository extends JpaRepository<CollateralMarketValueRealEstate, Integer> {
	
	CollateralMarketValueRealEstate findByCityAndState(String city, String state);
}