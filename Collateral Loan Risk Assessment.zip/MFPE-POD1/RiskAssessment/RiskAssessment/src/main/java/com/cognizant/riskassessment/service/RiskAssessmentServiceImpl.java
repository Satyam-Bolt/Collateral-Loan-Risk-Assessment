package com.cognizant.riskassessment.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.riskassessment.client.Collateralfeignclient;
import com.cognizant.riskassessment.client.LoanClient;
import com.cognizant.riskassessment.exception.CollateralNotFoundException;
import com.cognizant.riskassessment.exception.CustomerLoanNotFoundException;
import com.cognizant.riskassessment.exception.DataNotPresentException;
import com.cognizant.riskassessment.model.CollateralCashDeposits;
import com.cognizant.riskassessment.model.CollateralMarketValueCashDeposits;
import com.cognizant.riskassessment.model.CollateralMarketValueRealEstate;
import com.cognizant.riskassessment.model.CollateralRealEstate;
import com.cognizant.riskassessment.model.CollateralRisk;
import com.cognizant.riskassessment.model.CustomerLoan;
import com.cognizant.riskassessment.model.Messages;
import com.cognizant.riskassessment.repository.CollateralMarketValueCashDepositsRepository;
import com.cognizant.riskassessment.repository.CollateralMarketValueRealEstateRepository;
import com.cognizant.riskassessment.repository.RiskAssessmentRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service

/**
 * RiskAssessmentServiceImpl is the implementation 
 * of Service class
 *
 */

public class RiskAssessmentServiceImpl implements RiskAssessmentService {

	@Autowired
	private Collateralfeignclient collateralfeignclient;
	@Autowired
	private LoanClient loanClient;
	
	/** RiskAssessmentRepository is auto wired 
	 * with  riskAssessmentRepository object
	 * 
	 * CollateralMarketValueRealEstateRepository is auto wired
	 * with realEstateRepository object
	 *
	 * CollateralMarketValueCashDepositsRepository is auto wired 
	 *  with cashDepositsRepository object
	 *  
	 */
	@Autowired
	private RiskAssessmentRepository riskAssessmentRepository;

	@Autowired
	private CollateralMarketValueRealEstateRepository realEstateRepository;

	@Autowired
	private CollateralMarketValueCashDepositsRepository cashDepositsRepository;
	
	/**
	 * getRiskForRealEstate method return the 
	 * market value of collateral Real Estate 
	 * and calculate the risk percentage and SanctionedLoan  
	 * according  to market value 
	 * 
	 * 
	 * @param marketvalue
	 * @param current value
	 * @return
	 * @throws DataNotPresentException 
	 * @throws CollateralNotFoundException 
	 * @throws CustomerLoanNotFoundException 
	 */

	public CollateralRisk getRiskForRealEstate(String token, int loanId) throws  CollateralNotFoundException, CustomerLoanNotFoundException {
		
		CollateralRealEstate collateralRealEstate;

		CustomerLoan loan;
		double currentValue = 0;
		double marketValue = 0;
		CollateralMarketValueRealEstate marketValueRealEstate;

		log.info("Collaterals-Management Microservice is called");
		collateralRealEstate = collateralfeignclient.getCollateralForRealEstate(token, loanId).getBody();
		if(collateralRealEstate==null) {
			throw new CollateralNotFoundException(""+Messages.NOIDFOUND);
		}
		log.info("Loan-Management Microservice is called");
		loan = loanClient.getById(loanId, token).getBody();
		if(loan==null)
			throw new CustomerLoanNotFoundException(""+Messages.NOLOANINFO);
		else {
			currentValue = calculateCurrentValue(loan.getLoanPrincipal(), loan.getInterest(), loan.getTenureYear());
		}

		if (collateralRealEstate != null) {
			marketValueRealEstate = realEstateRepository.findByCityAndState(collateralRealEstate.getCity(),
					collateralRealEstate.getState());
			marketValue = marketValueRealEstate.getRatePerSqft() * collateralRealEstate.getAreaInFt();
		}

		double riskPercentage = calculateRiskPercentage(marketValue, currentValue);
		Optional<CollateralRisk> optionalCollateralRisk = riskAssessmentRepository.findByLoanIdAndCollateralType(loanId,
				"Real Estate");
		log.info("Optional Collateral"+optionalCollateralRisk);
		if (optionalCollateralRisk.isPresent()) {
			log.info("CollateralRisk1:{}",optionalCollateralRisk.isPresent());
			return optionalCollateralRisk.get();
		}else {
			log.info("this is ELSE");
			CollateralRisk newCollateralRisk = new CollateralRisk();
			newCollateralRisk.setCollateralType("Real Estate");
			newCollateralRisk.setLoanId(loanId);
			newCollateralRisk.setRiskPercentage(riskPercentage);
			newCollateralRisk.setMarketValue(marketValue);
			newCollateralRisk.setCollateralId(collateralRealEstate.getCollateralId());
			newCollateralRisk.setSanctionedLoan(isLoanSanctioned(riskPercentage));
			log.info("CollateralRisk:{}",newCollateralRisk);
			return riskAssessmentRepository.save(newCollateralRisk);
		}	

	}

	/**
	 * getRiskForCashDeposits method return the 
	 * market value of cash deposite 
	 * and calculate the risk percentage and SanctionedLoan  
	 * according  to market value 
	 * 
	 * 
	 * @param marketvalue
	 * @param current value
	 * @param Interest
	 * @param TenureYear
	 * @return
	 * @throws DataNotPresentException 
	 * @throws CollateralNotFoundException 
	 * @throws CustomerLoanNotFoundException 
	 */
	public CollateralRisk getRiskForCashDeposits(String token, int loanId) throws  CollateralNotFoundException, CustomerLoanNotFoundException {

		CollateralCashDeposits collateralCashDeposits;

		CustomerLoan loan;
		double currentValue = 0;
		double marketValue = 0;
		CollateralMarketValueCashDeposits marketValueCashDeposits;

		log.info("Collaterals-Management Microservice is called");
		collateralCashDeposits = collateralfeignclient.getCollateralForCashDeposit(token, loanId).getBody();
		if(collateralCashDeposits==null) {
			throw new CollateralNotFoundException(""+Messages.NOIDFOUND);
		}
		
		log.info("Loan-Management Microservice is called");

		loan = loanClient.getById(loanId, token).getBody();
		log.info("Loan-Management{}:", loan);
		if(loan==null)
			throw new CustomerLoanNotFoundException(""+Messages.NOLOANINFO);
		else {
			currentValue = calculateCurrentValue(loan.getLoanPrincipal(), loan.getInterest(), loan.getTenureYear());
		}

		if (collateralCashDeposits != null) {
			marketValueCashDeposits = cashDepositsRepository.findByBankName(collateralCashDeposits.getBankName());
			marketValue = collateralCashDeposits.getDepositAmount() + ((marketValueCashDeposits.getInterestRate()
					* collateralCashDeposits.getDepositAmount() * collateralCashDeposits.getLockPeriod()) / 100);
		}

		double riskPercentage = calculateRiskPercentage(marketValue, currentValue);
		Optional<CollateralRisk> optionalCollateralRisk = riskAssessmentRepository.findByLoanIdAndCollateralType(loanId,
				"Cash Deposits");
		if (optionalCollateralRisk.isPresent()) {

			return optionalCollateralRisk.get();
		}

		CollateralRisk newCollateralRiskCashDeposits = new CollateralRisk();
		newCollateralRiskCashDeposits.setCollateralType("Cash Deposits");
		newCollateralRiskCashDeposits.setLoanId(loanId);
		newCollateralRiskCashDeposits.setRiskPercentage(riskPercentage);
		newCollateralRiskCashDeposits.setMarketValue(marketValue);
		newCollateralRiskCashDeposits.setCollateralId(collateralCashDeposits.getCollateralId());
		newCollateralRiskCashDeposits.setSanctionedLoan(isLoanSanctioned(riskPercentage));
		log.info("CollateralRisk:",newCollateralRiskCashDeposits);
		return riskAssessmentRepository.save(newCollateralRiskCashDeposits);

	}
	/**
	 * calculating risk percentage
	 * @param marketValue
	 * @param currentValue
	 * @return
	 */

	public double calculateRiskPercentage(double marketValue, double currentValue) {

		double riskFactor = (marketValue / currentValue);

		if (riskFactor >= 1.5) {
			return 0;
		} else {
			if (riskFactor > 0.5 && riskFactor < 1.5) {
				return (150 - (riskFactor * 100));
			} else {
				return 100;
			}
		}
	}
	
	/**
	 * calculate market current value
	 * @param loanPrincipal
	 * @param interest
	 * @param tenureYear
	 * @return
	 */

	public double calculateCurrentValue(double loanPrincipal, double interest, int tenureYear) {

		return loanPrincipal + (loanPrincipal * interest * tenureYear)/100;

	}
	
	
	/**
	 * find sanctioned loan
	 * @param riskPercentage
	 * @return
	 */
	public boolean isLoanSanctioned(double riskPercentage) {
		if(riskPercentage >= 0 && riskPercentage <= 50) {
			return true;
		}else {
			return false;
		}
	}
}