insert into collateral_market_value_cash_deposits (market_id,bank_name,interest_rate) values (1,'SBI',4.50);
insert into collateral_market_value_cash_deposits (market_id,bank_name,interest_rate) values (2,'PNB',4.00);
insert into collateral_market_value_real_estate (market_id,city,state,rate_per_sqft) values (1,'chennai','tamilnadu',3800);
insert into collateral_market_value_real_estate (market_id,city,state,rate_per_sqft) values (2,'pune','maharashtra',2500);
