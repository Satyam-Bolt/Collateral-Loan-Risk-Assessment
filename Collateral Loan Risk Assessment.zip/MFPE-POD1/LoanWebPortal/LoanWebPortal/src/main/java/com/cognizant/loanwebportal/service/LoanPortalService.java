package com.cognizant.loanwebportal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.loanwebportal.feignproxy.AuthenticationFeign;
import com.cognizant.loanwebportal.feignproxy.LoanFeignClient;
import com.cognizant.loanwebportal.feignproxy.RiskFeignClient;
import com.cognizant.loanwebportal.model.CollateralCashDeposits;
import com.cognizant.loanwebportal.model.CollateralRealEstate;
import com.cognizant.loanwebportal.model.CollateralRisk;
import com.cognizant.loanwebportal.model.Customer;
import com.cognizant.loanwebportal.model.CustomerLoan;
import com.cognizant.loanwebportal.model.CustomerLoanData;
import com.cognizant.loanwebportal.model.Loan;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
/**
 * 
 * @Slf4j to generate getters and setters for all the model classes
 *
 */
@Slf4j
@Service
public class LoanPortalService {

	/**
	 * authFeign reference of AuthenticationFeign, it is autowired
	 */
	@Autowired
	AuthenticationFeign authFeign;

	/**
	 * 
	 * @param token
	 * @param name
	 * @return the index page
	 */
	public ModelAndView viewIndex(String token, String name) {
		log.info("viewIndex() method started");
		if (token != null) {
			
			log.info("index page authentication sucessfully");
			ModelAndView modelandview = new ModelAndView("index");
			modelandview.addObject("name", name);
			log.info("viewIndex() method ended");
			return modelandview;
		}
		return new ModelAndView("login");

	}

	/**
	 * 
	 * @param token
	 * @param name
	 * @return find-risk page where we have to give the details of the loan that we want to check risk of
	 * 
	 */
	public ModelAndView viewRisk(String token, String name) {
		log.info("viewRisk() method started");
		if (token != null) {
			log.info("view risk calling");
			ModelAndView modelAndView = new ModelAndView("find-risk");
			modelAndView.addObject("name", name);
			log.info("viewRisk() method ended");
			return modelAndView;
		} else {
			return new ModelAndView("login");
		}
	}

	/**
	 * 
	 * @param token
	 * @param name
	 * @param collateralRisk
	 * @param riskFeignClient
	 * @return the show-risk page where the calculated risk is displayed
	 */
	public ModelAndView showRiskPost(String token, String name, CollateralRisk collateralRisk,
			RiskFeignClient riskFeignClient) {
		log.info("showRiskPost() method started");
		if (token != null) {
			log.info("show risk calling");
			log.info(collateralRisk.getCollateralType());
			String str = collateralRisk.getCollateralType();
			CollateralRisk collateralRisk1 = null;
			if (str.equals("Real Estate")) {
				log.info("True");
				try {
					log.info("Try block");
					collateralRisk1 = riskFeignClient.getcollatrolrisk(token, collateralRisk.getLoanId()).getBody();
				} catch (Exception e) {
					log.info("Exception");
					e.printStackTrace();
					return new ModelAndView("find-risk");
				}
			} else {
				try {
					collateralRisk1 = riskFeignClient.getcollatrolriskForCashDeposits(token, collateralRisk.getLoanId())
							.getBody();
				} catch (Exception e) {
					log.info("Exception cash");
					return new ModelAndView("find-risk");
				}

			}
			ModelAndView modelandview = new ModelAndView("view-risk");
			modelandview.addObject("mlist", collateralRisk1);
			modelandview.addObject("name", collateralRisk1.getCollateralType());
			log.info("show-risk called");
			log.info("showRiskPost() method started");	
			return modelandview;
		} else {
			return new ModelAndView("login");
		}

	}

	/**
	 * 
	 * @param token
	 * @param name
	 * @return applay-loan page where we can apply for loan
	 */
	public ModelAndView applyLoan(String token, String name) {
		log.info("applyLoan() method started");
		if (token != null) {
			ModelAndView modelAndView = new ModelAndView("apply-loan");
			modelAndView.addObject("name", name);
			log.info("applyLoan() method ended");
			return modelAndView;
		} else {
			return new ModelAndView("login");
		}
	}

	/**
	 * 
	 * @param token
	 * @param customerLoanData
	 * @param loanloanFeignClient
	 * @return the collateral type page where we have to give the additional information for the loan
	 */
	public ModelAndView applyLoanPost(String token, CustomerLoanData customerLoanData,
			LoanFeignClient loanloanFeignClient) {
		log.info("applyLoanPost() method started");
		if (token != null) {
			Customer c = new Customer();
			c.setCustomerId(customerLoanData.getCustomerId());
         	Loan l = new Loan();
			l.setLoanProductId(customerLoanData.getLoanProductId());
			l.setLoanProductName(customerLoanData.getProductName());
			CustomerLoan customerLoan = new CustomerLoan();
			log.info("customerLoan.getLoanPrincipal(){}", customerLoanData.getLoanPrincipal());
			customerLoan.setLoanPrincipal(customerLoanData.getLoanPrincipal());
			customerLoan.setInterest(customerLoanData.getInterest());
			customerLoan.setTenureYear(customerLoanData.getTenureYear());
			//customerLoan.setEmi(customerLoanData.getEmi());
			customerLoan.setCustomer(c);
			customerLoan.setLoanProduct(l);
			log.info("loanFeignClient:{}", loanloanFeignClient);
			CustomerLoan newCustomer = loanloanFeignClient.saveCustomerLoan(token, customerLoan).getBody();

			ModelAndView modelAndView = new ModelAndView("collateral-type");
			modelAndView.addObject("name", newCustomer.getLoanId());
			log.info("applyLoanPost() method ended");
			return modelAndView;
		} else {
			return new ModelAndView("login");
		}
	}

	/**
	 * 
	 * @param token
	 * @param collateralType
	 * @param loanId
	 * @return cash-deposit-collateral page if collateral type is cash deposit and
	 *  real-estate-collateral page if collateral type is real estate   
	 */
	public ModelAndView collateral(String token, String collateralType, int loanId) {
		log.info("collateral() method started");
		if (token != null) {
			log.info(collateralType);
			log.info("loan id {}", loanId);
			ModelAndView modelAndView;
			if (collateralType.equals("Cash Deposit")) {
				modelAndView = new ModelAndView("cash-deposit-collateral");
			} else {
				modelAndView = new ModelAndView("real-state-collateral");
			}
			modelAndView.addObject("loanId", loanId);
			log.info("collateral() method ended");
			return modelAndView;
		} else {
			return new ModelAndView("login");
		}

	}

	/**
	 * 
	 * @param token
	 * @param name
	 * @param collateralCashDeposits
	 * @param loanFeignClient
	 * @return submit page for cash deposit
	 */
	@SuppressWarnings("unchecked")
	public ModelAndView collateralSaveBank(String token, String name, CollateralCashDeposits collateralCashDeposits,
			LoanFeignClient loanFeignClient) {

		log.info("collateralSaveBank() method started");
		if (token != null) {
			ModelAndView modelAndView = new ModelAndView("redirect:/cashSubmit");
			ObjectMapper mapper = new ObjectMapper();
			ResponseEntity<CollateralCashDeposits> customermap = (ResponseEntity<CollateralCashDeposits>) loanFeignClient
					.saveCollateralCashDeposit(token, collateralCashDeposits.getLoanId(), collateralCashDeposits);

			CollateralCashDeposits newCustomer1 = mapper.convertValue(customermap.getBody(),
					CollateralCashDeposits.class);
			log.info(newCustomer1.getOwnerName());
			modelAndView.addObject("name1", newCustomer1.getOwnerName());
			log.info("collateralSaveBank() method ended");
			return modelAndView;
			
		} else {
			return new ModelAndView("login");
		}

	}
/**
 * 
 * @param token
 * @param name
 * @param collateralRealEstate
 * @param loanFeignClient
 * @return submit page for real estate
 */
	@SuppressWarnings("unchecked")
	public ModelAndView collateralSaveRealState(String token, String name, CollateralRealEstate collateralRealEstate,
			LoanFeignClient loanFeignClient) {
		log.info("collateralSaveRealState() method started");
		if (token != null) {
			ObjectMapper mapper = new ObjectMapper();
			ModelAndView modelAndView = new ModelAndView("redirect:/realStateSubmit");
			ResponseEntity<CollateralRealEstate> customermap = (ResponseEntity<CollateralRealEstate>) loanFeignClient
					.saveCollateralRealEstate(token, collateralRealEstate.getLoanId(), collateralRealEstate);
			CollateralRealEstate newCustomer1 = mapper.convertValue(customermap.getBody(), CollateralRealEstate.class);
			log.info(newCustomer1.getOwnerName());
			modelAndView.addObject("name1", newCustomer1.getOwnerName());
			modelAndView.addObject("name", name);
			log.info("collateralSaveRealState() method ended");
			return modelAndView;
		} else {
			return new ModelAndView("submit");
		}
	}

}