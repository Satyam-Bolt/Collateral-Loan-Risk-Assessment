package com.cognizant.loanwebportal.model;

import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
/**
 * 
 * Pojo class for Customer Loan
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CustomerLoan {

	@NotEmpty
	private int loanId;
	private double loanPrincipal;
	private int tenureYear;
	private double interest;
	//private int emi;

	private int collateralId;

	private Customer customer;
	private Loan loanProduct;

}