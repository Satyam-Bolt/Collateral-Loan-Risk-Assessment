package com.cognizant.loanwebportal.feignproxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cognizant.loanwebportal.model.Admin;
import com.cognizant.loanwebportal.model.AuthResponse;
import com.cognizant.loanwebportal.model.UserToken;
/**
 * 
 * Feign client for authentication
 *
 */
@FeignClient(name = "AUTH",url = "${auth.path}")
public interface AuthenticationFeign {

	/**
	 * 
	 * @param userlogincredentials
	 * gets token
	 */
	@PostMapping(value="/login")
	public UserToken login(@RequestBody Admin userlogincredentials);
	/**
	 * 
	 * @param token
	 * verifies token
	 */
	@GetMapping(value="/validate")
	public ResponseEntity<AuthResponse> getValidity(@RequestHeader("Authorization") String token);
}