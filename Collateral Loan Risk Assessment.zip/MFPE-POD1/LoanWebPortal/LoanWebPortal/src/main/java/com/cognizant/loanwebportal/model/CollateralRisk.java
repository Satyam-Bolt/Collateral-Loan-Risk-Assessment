package com.cognizant.loanwebportal.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
/**
 * 
 * Pojo class for Collateral Risk
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CollateralRisk {

	private int riskId;
	private String collateralType;
	private int loanId;
	private int collateralId;
	private double riskPercentage;
	private double marketValue;
	private boolean sanctionedLoan;

}