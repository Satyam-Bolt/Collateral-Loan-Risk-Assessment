package com.cognizant.loanwebportal.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.loanwebportal.feignproxy.AuthenticationFeign;
import com.cognizant.loanwebportal.feignproxy.LoanFeignClient;
import com.cognizant.loanwebportal.feignproxy.RiskFeignClient;
import com.cognizant.loanwebportal.model.Admin;
import com.cognizant.loanwebportal.model.CollateralCashDeposits;
import com.cognizant.loanwebportal.model.CollateralRealEstate;
import com.cognizant.loanwebportal.model.CollateralRisk;
import com.cognizant.loanwebportal.model.CustomerLoanData;
import com.cognizant.loanwebportal.model.UserToken;
import com.cognizant.loanwebportal.service.LoanPortalService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @Slf4j to generate getters and setters for all the model classes
 *
 */
@Slf4j
@Controller
public class MainController {

	/**
	 * authFeign reference of AuthenticationFeign, it is autowired
	 */
	@Autowired
	private AuthenticationFeign authFeign;
	/**
	 * riskFeignClient reference of RiskFeignClient, it is autowired
	 */
	@Autowired
	RiskFeignClient riskFeignClient;

	/**
	 * loanFeign reference of LoanFeignClient, it is autowired
	 */
	@Autowired
	LoanFeignClient loanFeignClient;

	LoanPortalService loanPortalService = new LoanPortalService();

	/**
	 * 
	 * @return login page
	 */
	@RequestMapping(path = "/login", method = RequestMethod.GET)
	public ModelAndView getLogin() {
		log.debug("getLogin() method started");
		log.debug("login called");
		log.debug("getLogin() method ended");
		return new ModelAndView("login");
	}

	/**
	 * 
	 * @param user
	 * @param request after entering the login credential, if they are wrong, Wrong
	 *                credentials message is displayed else the user is successfully
	 *                logged in
	 */
	@RequestMapping(path = "/login", method = RequestMethod.POST)
	public ModelAndView postLogin(@ModelAttribute Admin user, HttpServletRequest request) {
		log.debug("postLogin() method started");
		UserToken res = null;
		try {
			res = authFeign.login(user);
		} catch (Exception e) {
			log.info("un succesfully login");
			ModelAndView modelAndView = new ModelAndView("login");
			modelAndView.addObject("error", "Wrong Credential!!");
			return modelAndView;
		}
		request.getSession().setAttribute("token", "Bearer " + res.getAuthToken());
		request.getSession().setAttribute("name", user.getUserid());
		log.debug(user.getUpassword());
		log.debug("succesfully login");
		log.debug("postLogin() method ended");
		return viewIndex1(request);
	}

	/**
	 * 
	 * @param request
	 * @return index page
	 */
	@RequestMapping(path = "/home", method = RequestMethod.GET)
	public ModelAndView viewIndex1(HttpServletRequest request) {
		log.debug("viewIndex1() method started");
		log.debug("home calling");
		String token = (String) request.getSession().getAttribute("token");
		String name = (String) request.getSession().getAttribute("name");
		log.debug("viewIndex1() method ended");
		return loanPortalService.viewIndex(token, name);
	}

	/**
	 * 
	 * @param request
	 * @return view-risk page
	 */
	@RequestMapping(path = "/view-risk", method = RequestMethod.GET)
	public ModelAndView viewRisk(HttpServletRequest request) {
		log.debug("viewRisk() method started");
		String token = (String) request.getSession().getAttribute("token");
		String name = (String) request.getSession().getAttribute("name");
		log.debug("viewRisk() method ended");
		return loanPortalService.viewRisk(token, name);

	}

	/**
	 * 
	 * @param request
	 * @param collateralRisk
	 * @return show-risk page
	 */
	@RequestMapping(path = "/show-risk", method = RequestMethod.POST)
	public ModelAndView showRiskPost(HttpServletRequest request,
			@ModelAttribute("collateralRisk") CollateralRisk collateralRisk) {
		log.debug("showRiskPost() method started");
		String token = (String) request.getSession().getAttribute("token");
		String name = (String) request.getSession().getAttribute("name");
		log.debug("showRiskPost() method ended");
		log.debug("colateral risk obj"+collateralRisk);
		return loanPortalService.showRiskPost(token, name, collateralRisk, riskFeignClient);
	}

	/**
	 * 
	 * @param request
	 * @return apply loan page
	 */
	@RequestMapping(path = "/apply-loan", method = RequestMethod.GET)
	public ModelAndView applyLoan(HttpServletRequest request,Model model ) {
		log.debug("applyLoan() method started");
		String token = (String) request.getSession().getAttribute("token");
		String name = (String) request.getSession().getAttribute("name");
		model.addAttribute("customerLoanData",new CustomerLoanData());
		log.debug("apply() method ended");
		return loanPortalService.applyLoan(token, name);

	}

	/**
	 * 
	 * @param request
	 * @param customerLoanData
	 * @param result
	 * @return
	 */
	@RequestMapping(path = "/apply-loan", method = RequestMethod.POST)
	public ModelAndView applyLoanPost(HttpServletRequest request,
			@ModelAttribute("customerLoanData") @Valid CustomerLoanData customerLoanData, BindingResult result) {
		log.debug("applyLoanPost() method started");
		log.debug("{}", customerLoanData.getLoanPrincipal());
		String token = (String) request.getSession().getAttribute("token");
		String name = (String) request.getSession().getAttribute("name");
		if(name.equalsIgnoreCase("geeta"))
		{
			customerLoanData.setCustomerId(101);
			customerLoanData.setLoanProductId(1001);
		}
		else if(name.equalsIgnoreCase("shilpa"))
		{
			customerLoanData.setCustomerId(102);
			customerLoanData.setLoanProductId(1002);
		}
		else if(name.equalsIgnoreCase("sabhya"))
		{
			customerLoanData.setCustomerId(103);
			customerLoanData.setLoanProductId(1003);
		}else
		{
			customerLoanData.setCustomerId(104);
			customerLoanData.setLoanProductId(1004);
		}
		if (result.hasErrors()) {
			return new ModelAndView("apply-loan");
		}
		log.debug("loanFeignClient:{}", loanFeignClient);
		log.debug("riskFeignClient:{}", riskFeignClient);
		log.debug("applyLoanPost() method ended");
		return loanPortalService.applyLoanPost(token, customerLoanData, loanFeignClient);

	}

	/**
	 * 
	 * @param loanId
	 * @param request
	 * @param collateralType
	 * @return collateral type page where the user need to enter which collateral he
	 *         will be using for loan
	 */
	@RequestMapping(path = "/collateral", method = RequestMethod.GET)
	public ModelAndView collateral(@RequestParam("loanId") Integer loanId, HttpServletRequest request,
			@RequestParam("collateralType") String collateralType, Model model) {
		log.debug("collateral() method started");
		String token = (String) request.getSession().getAttribute("token");
//		String name = (String) request.getSession().getAttribute("name");
		log.debug("collateral() method ended");
		model.addAttribute("collateralRealEstate",new CollateralRealEstate() );
		model.addAttribute("collateralCashDeposits",new CollateralCashDeposits());
		return loanPortalService.collateral(token, collateralType, loanId);

	}

	/**
	 * 
	 * @param request
	 * @param collateralCashDeposits
	 * @param bindingResult
	 * @return cash deposit details page
	 */
	@RequestMapping(path = "/collateral/bankdeposit", method = RequestMethod.POST)
	public ModelAndView collateralSaveBank(HttpServletRequest request,
			@ModelAttribute("collateralCashDeposits") @Valid CollateralCashDeposits collateralCashDeposits,
			BindingResult bindingResult) {
		log.debug("collateralSaveBank() method started");
		String token = (String) request.getSession().getAttribute("token");
		String name = (String) request.getSession().getAttribute("name");
		log.debug("collateralSaveBank() method ended");
		return loanPortalService.collateralSaveBank(token, name, collateralCashDeposits, loanFeignClient);

	}

	/**
	 * 
	 * @param request
	 * @param collateralRealEstate
	 * @param bindingResult
	 * @return real estate details page
	 */
	@RequestMapping(path = "/collateral/realstate", method = RequestMethod.POST)
	public ModelAndView collateralSaveRealState(HttpServletRequest request,
			@ModelAttribute("collateralRealEstate") @Valid CollateralRealEstate collateralRealEstate,
			BindingResult bindingResult) {
		log.debug("collateralSaveRealState() method started");
		String token = (String) request.getSession().getAttribute("token");
		String name = (String) request.getSession().getAttribute("name");
		log.debug("collateralSaveRealState() 2nd  method started");
		
		//My modification here
		
		/*if (bindingResult.hasErrors()) {
			log.info("binding result started");
			ModelAndView modelAndView=new ModelAndView("real-state-collateral");
			modelAndView.addObject("loanId",collateralRealEstate.getLoanId());
			return modelAndView;
		}*/
		log.debug("collateralSaveRealState() method ended");
		return loanPortalService.collateralSaveRealState(token, name, collateralRealEstate, loanFeignClient);

	}

	/**
	 * 
	 * @param request
	 * @return submit page for Cash deposit
	 */
	@RequestMapping(path = "/cashSubmit", method = RequestMethod.GET)
	public ModelAndView collateralCashSave(HttpServletRequest request) {
		log.debug("collateralCashSave() method started");
//		String token = (String) request.getSession().getAttribute("token");
		ModelAndView modelandview = new ModelAndView("submit");
		String username = request.getParameter("name1");
		log.debug(username);
		modelandview.addObject("username", username);
		log.debug("collateralCashSave() method ended");
		return modelandview;
	}

	/**
	 * 
	 * @param request
	 * @return submit page for real estate
	 */
	@RequestMapping(path = "/realStateSubmit", method = RequestMethod.GET)
	public ModelAndView collateralRealSave(HttpServletRequest request) {
		log.debug("collateralRealSave() method started");
//		String token = (String) request.getSession().getAttribute("token");
		ModelAndView modelandview = new ModelAndView("submit");
		String username = request.getParameter("name1");
		log.debug(username);
		modelandview.addObject("username", username);
		log.debug("collateralRealSave() method ended");
		return modelandview;
	}

	/**
	 * 
	 * @param session
	 * @return login page invalidates the session
	 */
	@RequestMapping(path = "/logout", method = RequestMethod.GET)
	public ModelAndView logout(HttpSession session) {
		log.debug("logout() method started");
		session.setAttribute("token", null);
		session.setAttribute("name", null);
		session.invalidate();
		log.debug("logout() method ended");
		return new ModelAndView("login");
	}
}