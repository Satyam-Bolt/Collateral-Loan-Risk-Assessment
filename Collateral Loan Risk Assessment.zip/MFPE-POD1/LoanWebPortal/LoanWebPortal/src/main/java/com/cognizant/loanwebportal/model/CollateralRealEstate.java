package com.cognizant.loanwebportal.model;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
/**
 * 
 * Pojo class for Real Estate Collateral
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CollateralRealEstate {

	private int collateralId;

	private int loanId;
	
	
	@NotBlank(message="Please enter the owner name")
	private String ownerName;
	@NotBlank(message="Please enter the address")
	private String address;
	
	private String city;
	
	private String state;
	
	@Min(value=1,message="value of areaInft should be minimum 1")
	private Integer areaInFt;

}