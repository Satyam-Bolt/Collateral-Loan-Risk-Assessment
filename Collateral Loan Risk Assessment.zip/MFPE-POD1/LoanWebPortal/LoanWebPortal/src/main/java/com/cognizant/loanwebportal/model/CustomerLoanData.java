package com.cognizant.loanwebportal.model;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * 
 * Pojo class for customer loan data
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerLoanData {

	private int loanId;
	@NotNull(message = "loan product required")
	private int loanProductId;
	@NotNull(message = "customerIdrequired")
	private int customerId;
	@Min(value=10000, message = "principal value should be >=10000")
	private Double loanPrincipal;
	@NotNull(message = "tenureYear required")
	@Min(value=1, message = "tenure year should be minimum 1")
	private Integer tenureYear;
	
	private double interest;
	
	private int collateralId;
	@NotBlank(message="Please enter the product name")
	@NotEmpty(message="this should not be empty")
	private String productName;
}