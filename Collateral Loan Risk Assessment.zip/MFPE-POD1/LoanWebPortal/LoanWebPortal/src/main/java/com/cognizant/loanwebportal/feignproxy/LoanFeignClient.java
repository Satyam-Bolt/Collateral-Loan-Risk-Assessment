package com.cognizant.loanwebportal.feignproxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cognizant.loanwebportal.model.CollateralCashDeposits;
import com.cognizant.loanwebportal.model.CollateralRealEstate;
import com.cognizant.loanwebportal.model.CustomerLoan;
/**
 * 
 * Feign client for Loan service
 *
 */
@FeignClient(name = "loan-service", url = "${loan.path}")
public interface LoanFeignClient {

 
	/**
	 * 
	 * @param token
	 * @param customerLoan
	 * saves customer loan
	 */
	@PostMapping(path = "/saveCustomerLoan")
	public ResponseEntity<CustomerLoan> saveCustomerLoan(@RequestHeader(name = "Authorization") String token,
			@RequestBody CustomerLoan customerLoan);

	/**
	 * 
	 * @param loanId
	 * @param token
	 * get loan by Id
	 */
	@GetMapping(path = "loan/{loanId}")
	public ResponseEntity<?> getById(@PathVariable("loanId") int loanId,
			@RequestHeader(name = "Authorization") String token);

	/**
	 * 
	 * @param token
	 * @param loanId
	 * get collateral for cash deoosit
	 */
	@GetMapping("/getCollaterals/cashDeposits/{loanId}")
	public ResponseEntity<?> getCollateralForCashDeposit(@RequestHeader(name = "Authorization") String token,
			@PathVariable("loanId") int loanId);

	/**
	 * 
	 * @param token
	 * @param loanId
	 * @param collateralCashDeposits
	 * save customer loan cash deposit
	 */
	@PostMapping(path = "/saveCustomerLoan/cashDeposit/{loanId}")
	public ResponseEntity<?> saveCollateralCashDeposit(@RequestHeader(name = "Authorization") String token,
			@PathVariable("loanId") int loanId, @RequestBody CollateralCashDeposits collateralCashDeposits);

	/**
	 * 
	 * @param token
	 * @param loanId
	 * @param collateralRealEstate
	 * save customer loan for real estate
	 */
	@PostMapping(path = "/saveCustomerLoan/realEstate/{loanId}")
	public ResponseEntity<?> saveCollateralRealEstate(@RequestHeader(name = "Authorization") String token,
			@PathVariable("loanId") int loanId, @RequestBody CollateralRealEstate collateralRealEstate);

}