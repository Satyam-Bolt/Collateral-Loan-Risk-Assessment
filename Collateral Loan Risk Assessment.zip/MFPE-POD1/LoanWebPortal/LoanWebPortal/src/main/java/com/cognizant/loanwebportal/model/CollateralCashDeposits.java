package com.cognizant.loanwebportal.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
/**
 * 
 * Pojo class for Cash deposit Collateral
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CollateralCashDeposits {

	private int loanId;
	
	private String ownerName;
	
	private String bankName;
	
	private Long accountNumber;
	
	private Double depositAmount;
	
	private Double lockPeriod;
	private int collateralId;

}