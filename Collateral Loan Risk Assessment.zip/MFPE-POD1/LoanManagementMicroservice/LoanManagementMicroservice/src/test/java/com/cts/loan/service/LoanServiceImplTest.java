package com.cts.loan.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

//import org.junit.Rule;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
//import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cognizant.loanmanagement.exception.CustomerLoanNotFoundException;
import com.cognizant.loanmanagement.exception.DataNotPresentException;
import com.cognizant.loanmanagement.model.Customer;
import com.cognizant.loanmanagement.model.CustomerLoan;
import com.cognizant.loanmanagement.model.Loan;
import com.cognizant.loanmanagement.repository.CustomerLoanRepository;
import com.cognizant.loanmanagement.service.LoanServiceImpl;

@ExtendWith(MockitoExtension.class)
class LoanServiceImplTest {
	
	@Mock
	private CustomerLoanRepository customerLoanRepo;
	
	@InjectMocks
	LoanServiceImpl loanServiceImpl;
	
	
	
	@Test
	
	void testFindByCustomerLoanId_1() throws  CustomerLoanNotFoundException {
		Customer customer = new Customer(1,"geeta");
		Loan loan = new Loan(1,"house",10,8,10,"RealEstate");
		CustomerLoan customerLoan = new CustomerLoan(1,1000000.0,8,5000,customer,loan);
		when(customerLoanRepo.findById(1)).thenReturn(Optional.of(customerLoan));
		assertEquals(1, loanServiceImpl.findByCustomerLoanId(1).getLoanId());
	}
	
	@Test
	
	void testFindByCustomerLoanId_2() throws  CustomerLoanNotFoundException{
		Customer customer = new Customer(1,"geeta");
		Loan loan = new Loan(1,"house",10,8,10,"RealEstate");
		CustomerLoan customerLoan = new CustomerLoan(1,1000000.0,8,5000,customer,loan);
		when(customerLoanRepo.findById(1)).thenReturn(Optional.of(customerLoan));
		assertNotEquals(2, loanServiceImpl.findByCustomerLoanId(1).getLoanId());
	}
	
	@Test
	@ExceptionHandler(CustomerLoanNotFoundException.class)
	void testFindByCustomerLoanId_3() throws CustomerLoanNotFoundException{
		Customer customer = new Customer(1,"Danish");
		Loan loan = new Loan(1,"house",10,8,10,"RealEstate");
		CustomerLoan customerLoan = new CustomerLoan(1,1000000.0,8,5000,customer,loan);
		when(customerLoanRepo.findById(1)).thenReturn(Optional.of(customerLoan));
		assertEquals(1, loanServiceImpl.findByCustomerLoanId(1).getLoanId());
		assertNotEquals(2, loanServiceImpl.findByCustomerLoanId(1).getLoanId());
	}
	
	@Test
	@ExceptionHandler(CustomerLoanNotFoundException.class)
	void testFindByCustomerLoanId_4() throws  CustomerLoanNotFoundException{
		Customer customer = new Customer(1,"geeta");
		Loan loan = new Loan(1,"house",10,8,10,"RealEstate");
		CustomerLoan customerLoan = new CustomerLoan(1,1000000.0,8,5000,customer,loan);
		when(customerLoanRepo.findById(1)).thenReturn(Optional.of(customerLoan));
		assertNotEquals(5000, loanServiceImpl.findByCustomerLoanId(1).getLoanPrincipal());
	}
	
	@Test
	
	void testFindByCustomerLoanId_5() throws  CustomerLoanNotFoundException{
		Customer customer = new Customer(1,"geeta");
		Loan loan = new Loan(1,"house",10,8,10,"RealEstate");
		CustomerLoan customerLoan = new CustomerLoan(1,1000000.0,8,5000,customer,loan);
		when(customerLoanRepo.findById(1)).thenReturn(Optional.of(customerLoan));
		assertNotEquals(15, loanServiceImpl.findByCustomerLoanId(1).getTenureYear());
	}
	@Test
	
	void testFindByCustomerLoanId_6() throws  CustomerLoanNotFoundException{
		Customer customer =null;
		Loan loan = new Loan(1,"house",10,8,10,"RealEstate");
		CustomerLoan customerLoan = new CustomerLoan(1,1000000.0,8,5000,customer,loan);
		when(customerLoanRepo.findById(1)).thenReturn(Optional.of(customerLoan));
		assertNotEquals(15, loanServiceImpl.findByCustomerLoanId(1).getTenureYear());
	}
	@Test
	
	void testFindByCustomerLoanId_7() throws  CustomerLoanNotFoundException{
		Customer customer = new Customer(1,"geeta");
		Loan loan = null;
		CustomerLoan customerLoan = new CustomerLoan(1,1000000.0,8,5000,customer,loan);
		when(customerLoanRepo.findById(1)).thenReturn(Optional.of(customerLoan));
		assertNotEquals(15, loanServiceImpl.findByCustomerLoanId(1).getTenureYear());
	}
	@Test
	
	void testFindByCustomerLoanId_8() throws  CustomerLoanNotFoundException{
		Customer customer = null;
		Loan loan = null;
		CustomerLoan customerLoan = new CustomerLoan(1,1000000.0,8,5000,customer,loan);
		when(customerLoanRepo.findById(1)).thenReturn(Optional.of(customerLoan));
		
		assertNotEquals(15, loanServiceImpl.findByCustomerLoanId(1).getTenureYear());
	}
	
	
	
	
	@Test
	
	void testSaveCustomerLoan_1() throws DataNotPresentException{
		Customer customer = new Customer(1,"sabhya");
		Loan loan = new Loan(1,"house",10,8,10,"RealEstate");
		CustomerLoan customerLoan = new CustomerLoan(1,2000000.0,7,8000,customer,loan);
		when(customerLoanRepo.save(customerLoan)).thenReturn(customerLoan);
		assertEquals(1,loanServiceImpl.saveCustomerLoan(customerLoan).getLoanId());
		}
	@Test
	
	void testSaveCustomerLoan_2() throws DataNotPresentException{
		Customer customer = new Customer(1,"sabhya");
		Loan loan = new Loan(1,"house",10,8,10,"RealEstate");
		CustomerLoan customerLoan = new CustomerLoan(1,2000000.0,7,8000,customer,loan);
		when(customerLoanRepo.save(customerLoan)).thenReturn(customerLoan);
		assertNotEquals(4,loanServiceImpl.saveCustomerLoan(customerLoan).getLoanId());
		}
	
	@Test
	
	void testSaveCustomerLoan_3() throws DataNotPresentException{
		Customer customer = new Customer(1,"geeta");
		Loan loan = new Loan(1,"house",10,8,10,"RealEstate");
		CustomerLoan customerLoan = new CustomerLoan(1,2000000.0,7,8000,customer,loan);
		when(customerLoanRepo.save(customerLoan)).thenReturn(customerLoan);
		assertEquals(7,loanServiceImpl.saveCustomerLoan(customerLoan).getTenureYear());
		}
	@Test
	@ExceptionHandler(DataNotPresentException.class)
	void testSaveCustomerLoan_4() throws DataNotPresentException{
		Customer customer = new Customer(1,"sabhya");
		Loan loan = new Loan(1,"house",10,8,10,"RealEstate");
		CustomerLoan customerLoan = new CustomerLoan(1,2000000.0,7,8000,customer,loan);
		when(customerLoanRepo.save(customerLoan)).thenReturn(customerLoan);
		assertNotEquals(9,loanServiceImpl.saveCustomerLoan(customerLoan).getTenureYear());
		}
	
	@Test
	
	void testSaveCustomerLoan_5() throws DataNotPresentException{
		Customer customer = new Customer(1,"geeta");
		Loan loan = new Loan(1,"house",10,8,10,"RealEstate");
		CustomerLoan customerLoan = new CustomerLoan(1,2000000.0,7,8000,customer,loan);
		when(customerLoanRepo.save(customerLoan)).thenReturn(customerLoan);
		assertNotEquals("CashDeposit",loanServiceImpl.saveCustomerLoan(customerLoan).getLoanProduct());
		}
	@Test
	
	void testSaveCustomerLoan_6() throws DataNotPresentException{
		Customer customer = null;
		Loan loan = new Loan(1,"house",10,8,10,"RealEstate");
		CustomerLoan customerLoan = new CustomerLoan(1,2000000.0,7,8000,customer,loan);
		when(customerLoanRepo.save(customerLoan)).thenReturn(customerLoan);
		assertNotEquals("CashDeposit",loanServiceImpl.saveCustomerLoan(customerLoan).getLoanProduct());
		}
	@Test
	
	void testSaveCustomerLoan_7() throws DataNotPresentException{
		Customer customer = null;
		Loan loan = null;
		CustomerLoan customerLoan = new CustomerLoan(1,2000000.0,7,8000,customer,loan);
		when(customerLoanRepo.save(customerLoan)).thenReturn(customerLoan);
		assertNotEquals("CashDeposit",loanServiceImpl.saveCustomerLoan(customerLoan).getLoanProduct());
		}
	@Test
	@ExceptionHandler(DataNotPresentException.class)
	void testSaveCustomerLoan_8() throws DataNotPresentException{
		Customer customer = new Customer(1,"geeta");
		Loan loan = null;
		CustomerLoan customerLoan = new CustomerLoan(1,2000000.0,7,8000,customer,loan);
		when(customerLoanRepo.save(customerLoan)).thenReturn(customerLoan);
		assertNotEquals("CashDeposit",loanServiceImpl.saveCustomerLoan(customerLoan).getLoanProduct());
		}
	
	@Test
	
	void testGetAllCustomerLoan_1() {
		Customer customer = new Customer(1,"geeta");
		Loan loan = new Loan(1,"house",10,8,10,"RealEstate");
		CustomerLoan customerLoan = new CustomerLoan(1,2000000.0,7,8000,customer,loan);
		when(customerLoanRepo.findAll()).thenReturn(List.of(customerLoan));
		assertEquals(1,loanServiceImpl.getAllCustomerLoan().get(0).getLoanId());
        }
	
	@Test
		void testGetAllCustomerLoan_2() {
		Customer customer = new Customer(1,"geeta");
		Loan loan = new Loan(1,"house",10,8,10,"RealEstate");
		CustomerLoan customerLoan = new CustomerLoan(1,2000000.0,7,8000,customer,loan);
		when(customerLoanRepo.findAll()).thenReturn(List.of(customerLoan));
		assertNotEquals(2,loanServiceImpl.getAllCustomerLoan().get(0).getLoanId());
	}
	
	@Test
	
	void testGetAllCustomerLoan_3() {
		Customer customer = new Customer(1,"geeta");
		Loan loan = new Loan(1,"house",10,8,10,"RealEstate");
		CustomerLoan customerLoan = new CustomerLoan(1,2000000.0,7,8000,customer,loan);
		when(customerLoanRepo.findAll()).thenReturn(List.of(customerLoan));
		assertNotEquals(7000,loanServiceImpl.getAllCustomerLoan().get(0).getTenureYear());
    }
	
	@Test
	
	void testGetAllCustomerLoan_4() {
		Customer customer = new Customer(1,"geeta");
		Loan loan = new Loan(1,"house",10,8,10,"RealEstate");
		CustomerLoan customerLoan = new CustomerLoan(1,2000000.0,7,8000,customer,loan);
		when(customerLoanRepo.findAll()).thenReturn(List.of(customerLoan));
		assertNotEquals(2.0,loanServiceImpl.getAllCustomerLoan().get(0).getInterest());
    }
	
	@Test
	
	void testGetAllCustomerLoan_5() {
		Customer customer = new Customer(1,"geeta");
		Loan loan = new Loan(1,"house",10,8,10,"RealEstate");
		CustomerLoan customerLoan = new CustomerLoan(1,2000000.0,7,8.0,customer,loan);
		when(customerLoanRepo.findAll()).thenReturn(List.of(customerLoan));
		assertEquals(8.0,loanServiceImpl.getAllCustomerLoan().get(0).getInterest());
    }
}