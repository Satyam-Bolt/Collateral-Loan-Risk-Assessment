Insert into customer(customer_id,customer_name) values (101,'geeta');
Insert into customer(customer_id,customer_name) values (102,'shilpa');
Insert into customer(customer_id,customer_name) values (103,'sabhya');
Insert into customer(customer_id,customer_name) values (104,'satyam');

Insert into loan (loanproduct_id,loanproduct_name ,max_Loan_eligible, interest ,tenure_year ,collateral_type) values(1001,'house', 10 ,8,10,'RealEstate');
Insert into loan (loanproduct_id, loanproduct_name ,max_Loan_eligible, interest ,tenure_year ,collateral_type) values(1002,'mobile',100,8,10,'CashDeposit');
Insert into loan (loanproduct_id,loanproduct_name ,max_Loan_eligible, interest ,tenure_year ,collateral_type) values(1003,'house', 10 ,8,10,'RealEstate');
Insert into loan (loanproduct_id, loanproduct_name ,max_Loan_eligible, interest ,tenure_year ,collateral_type) values(1004,'mobile',100,8,10,'CashDeposit');
