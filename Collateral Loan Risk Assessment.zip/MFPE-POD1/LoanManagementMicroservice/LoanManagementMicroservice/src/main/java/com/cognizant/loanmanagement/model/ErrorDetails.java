package com.cognizant.loanmanagement.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * Pojo class for Real Estate Error Details
 * @Data to implicitly have @Getter, @Setter, @ToString,
 * @EqualsAndHashCode and @RequiredArgsConstructor
 * annotations on the class
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ErrorDetails {

	private Date date;
	private String message;

}
