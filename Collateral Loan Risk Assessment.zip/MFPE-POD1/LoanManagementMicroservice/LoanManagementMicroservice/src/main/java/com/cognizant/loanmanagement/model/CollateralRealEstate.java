package com.cognizant.loanmanagement.model;

//import org.bouncycastle.tsp.PartialHashTreeVerificationException;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * Pojo class for Real Estate Collaterals
 * @Data to implicitly have @Getter, @Setter, @ToString,
 * @EqualsAndHashCode and @RequiredArgsConstructor
 * annotations on the class
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CollateralRealEstate {

	
	private int collateralId;
	
	private int loanId;
	
	private String ownerName;
	
	private String address;
	
	private String city;
	
	private String state;
	
	private int areaInFt;
}
