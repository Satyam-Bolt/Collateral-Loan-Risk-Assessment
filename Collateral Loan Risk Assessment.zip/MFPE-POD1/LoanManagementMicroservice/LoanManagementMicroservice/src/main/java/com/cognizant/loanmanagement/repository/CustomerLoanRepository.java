package com.cognizant.loanmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.loanmanagement.model.CustomerLoan;

/**
 * 
 * CustomerLoanRepository extends JPARepository
 *
 */
@Repository
public interface CustomerLoanRepository extends JpaRepository<CustomerLoan, Integer>{

}
