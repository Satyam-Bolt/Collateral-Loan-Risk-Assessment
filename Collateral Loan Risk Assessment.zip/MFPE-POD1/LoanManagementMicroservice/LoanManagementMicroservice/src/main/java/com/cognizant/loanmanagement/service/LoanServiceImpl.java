package com.cognizant.loanmanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.loanmanagement.exception.CustomerLoanNotFoundException;
import com.cognizant.loanmanagement.exception.DataNotPresentException;
import com.cognizant.loanmanagement.model.CustomerLoan;
import com.cognizant.loanmanagement.model.Messages;
import com.cognizant.loanmanagement.repository.CustomerLoanRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * Service class
 *
 */
@Service
@Slf4j
public class LoanServiceImpl implements LoanService {

	/**
	 * customerLoanRepo reference of CustomerLoanRepository is autowired in this class
	 */
	@Autowired
	CustomerLoanRepository customerLoanRepo;

	/**
	 * finds loan details on the basis of customer loan id
	 * @throws DataNotPresentException 
	 * @throws CustomerLoanNotFoundException 
	 */
	@Override
	public CustomerLoan findByCustomerLoanId(int loanId) throws  CustomerLoanNotFoundException {
		log.info("findById() method called");
		Optional<CustomerLoan> loan = customerLoanRepo.findById(loanId);
		if(!loan.isPresent()) {
			throw new CustomerLoanNotFoundException("The customer loan with given loan id is not present");
		}
		return customerLoanRepo.findById(loanId).get();
	}

	/**
	 * saves customer loans
	 * @throws DataNotPresentException 
	 */
	@Override
	public CustomerLoan saveCustomerLoan(CustomerLoan customerLoan) throws DataNotPresentException {

		log.info("saveCustomerLoan() method called");
		log.debug("customer loan:{}", customerLoan);
		if(customerLoan==null) {
			throw new DataNotPresentException(""+Messages.NODATA);
		}
		return customerLoanRepo.save(customerLoan);
	}

	/**
	 * get the loan details of all the customers
	 */
	@Override
	public List<CustomerLoan> getAllCustomerLoan() {

		log.info("getAllCustomerLoan() method called");
		return customerLoanRepo.findAll();
	}

}