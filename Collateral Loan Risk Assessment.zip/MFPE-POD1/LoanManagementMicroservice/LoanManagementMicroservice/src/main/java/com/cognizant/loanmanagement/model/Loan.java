package com.cognizant.loanmanagement.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * entity class for Loan
 * @Entity indicates Spring Data JPA that it is an entity class for the
 *         application
 * @Table helps in defining the mapping database table 
 *
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "loan")
public class Loan {
	
	/**
	 * instance variables
	 * 
	 * @Id helps in defining the primary key
	 * @Column helps in defining the mapping table column
	 * 
	 */
	@Id
	@Column(name = "loanproduct_id")
	private int loanProductId;

	@Column(name = "loanproduct_name")
	private String loanProductName;

	@Column(name = "max_Loan_eligible")
	private int maxLoanEligible;

	@Column(name = "interest") // maxLoan_eligible interest tenure_year collateral_type
	private double interest;

	@Column(name = "tenure_year")
	private int tenureYear;

	@Column(name = "collateral_type")
	private String collateralType;

}
