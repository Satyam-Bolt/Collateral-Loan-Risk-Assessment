package com.cognizant.loanmanagement.exception;

public class CustomerLoanNotFoundException extends Exception{

	public CustomerLoanNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
