
package com.cognizant.loanmanagement.service;

import java.util.List;

import com.cognizant.loanmanagement.exception.CustomerLoanNotFoundException;
import com.cognizant.loanmanagement.exception.DataNotPresentException;
import com.cognizant.loanmanagement.model.CustomerLoan;

/**
 * 
 * Service Interface for loose coupling
 *
 */
public interface LoanService {

	/**
	 * 
	 * @param loanId
	 * method to get loan details on the basis of Customer Loan Id
	 * @throws DataNotPresentException 
	 * @throws CustomerLoanNotFoundException 
	 */
	public CustomerLoan findByCustomerLoanId(int loanId) throws  CustomerLoanNotFoundException;

	/**
	 * 
	 * @param customerLoan
	 * method to save customer loan details
	 */
	public CustomerLoan saveCustomerLoan(CustomerLoan customerLoan) throws DataNotPresentException;

	/**
	 * 
	 * method to get the loan details of all the customers
	 */
	public List<CustomerLoan> getAllCustomerLoan() throws DataNotPresentException;
}