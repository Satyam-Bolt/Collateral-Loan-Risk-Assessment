package com.cognizant.loanmanagement.model;

public enum Messages {
	LOGIN("Login"),
	AUTHSUCCESS("Authorization Successful"),
	AUTHUNSUCCESS("Authorization Unsuccessful"),
	INVALIDTOKEN("Invalid Token"),
	NODATA("This data is not available in database"),
	NOLOANID("The customer loan with given loan id is not present");
	private String message;
	public String getMessage() {
		return message;
	}
	private Messages(String message) {
		this.message = message;
	}
}
