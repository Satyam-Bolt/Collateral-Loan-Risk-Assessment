package com.cognizant.authorization.controlller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import com.cognizant.authorization.controller.AuthController;
import com.cognizant.authorization.exception.InvalidAuthorizationException;
import com.cognizant.authorization.model.Admin;
import com.cognizant.authorization.model.AuthResponse;
import com.cognizant.authorization.repository.UserRepository;
import com.cognizant.authorization.service.CustomerDetailsService;
import com.cognizant.authorization.service.JwtUtil;

@SpringBootTest

public class AuthControllerTest {
	
	@InjectMocks
	AuthController authController;
	
	AuthResponse authResponse;
	UserDetails userdetails;
	
	
	
	@Mock
	JwtUtil jwtutil;
	
	@Mock
	CustomerDetailsService custdetailservice;
	
	@Mock
	UserRepository userservice;
	
	

	
	
	@Test
	void loginTest() throws InvalidAuthorizationException {
		Admin admin= new Admin("geeta","geeta",null,null);
		UserDetails loadUserByUsername = custdetailservice.loadUserByUsername(admin.getUserid());
		UserDetails value = new User(admin.getUserid(), admin.getUpassword(), new ArrayList<>());
		when(custdetailservice.loadUserByUsername(admin.getUserid())).thenReturn(value);
		when(jwtutil.generateToken(loadUserByUsername)).thenReturn("token");
		ResponseEntity<?> login = authController.login(admin);
		assertEquals( 200, login.getStatusCodeValue());
	}
	@Test
	void loginTest2() throws InvalidAuthorizationException {
		Admin admin= new Admin("sabhya","sabhya",null,null);
		UserDetails loadUserByUsername = custdetailservice.loadUserByUsername(admin.getUserid());
		UserDetails value = new User(admin.getUserid(), admin.getUpassword(), new ArrayList<>());
		when(custdetailservice.loadUserByUsername(admin.getUserid())).thenReturn(value);
		when(jwtutil.generateToken(loadUserByUsername)).thenReturn("token");
		ResponseEntity<?> login = authController.login(admin);
		assertEquals( 200, login.getStatusCodeValue());
	}

	@Test
	void loginTest3() throws InvalidAuthorizationException {
		Admin admin= new Admin("satyam","satyam",null,null);
		UserDetails loadUserByUsername = custdetailservice.loadUserByUsername(admin.getUserid());
		UserDetails value = new User(admin.getUserid(), admin.getUpassword(), new ArrayList<>());
		when(custdetailservice.loadUserByUsername(admin.getUserid())).thenReturn(value);
		when(jwtutil.generateToken(loadUserByUsername)).thenReturn("token");
		ResponseEntity<?> login = authController.login(admin);
		assertEquals( 200, login.getStatusCodeValue());
	}

	@Test
	void loginTest4() throws InvalidAuthorizationException {
		Admin admin= new Admin("shilpa","shilpa",null,null);
		UserDetails loadUserByUsername = custdetailservice.loadUserByUsername(admin.getUserid());
		UserDetails value = new User(admin.getUserid(), admin.getUpassword(), new ArrayList<>());
		when(custdetailservice.loadUserByUsername(admin.getUserid())).thenReturn(value);
		when(jwtutil.generateToken(loadUserByUsername)).thenReturn("token");
		ResponseEntity<?> login = authController.login(admin);
		assertEquals( 200, login.getStatusCodeValue());
	}


	@Test()
	
	 void loginTestFailed() throws InvalidAuthorizationException {

		Admin admin = new Admin("geeta", "geeta",null,null);
		UserDetails loadUserByUsername = custdetailservice.loadUserByUsername(admin.getUserid());
		UserDetails value = new User(admin.getUserid(), admin.getUpassword()+"wrong", new ArrayList<>());
		when(custdetailservice.loadUserByUsername(admin.getUserid())).thenReturn(value);
		when(jwtutil.generateToken(loadUserByUsername)).thenReturn("token");
		assertThrows(InvalidAuthorizationException.class,()-> authController.login(admin));
		
	    
	}
	@Test()
	
	 void loginTestFailed2() throws InvalidAuthorizationException {

		Admin admin = new Admin("sabhya", "sabhya",null,null);
		UserDetails loadUserByUsername = custdetailservice.loadUserByUsername(admin.getUserid());
		UserDetails value = new User(admin.getUserid(), admin.getUpassword()+"wrong", new ArrayList<>());
		when(custdetailservice.loadUserByUsername(admin.getUserid())).thenReturn(value);
		when(jwtutil.generateToken(loadUserByUsername)).thenReturn("token");
		assertThrows(InvalidAuthorizationException.class,()-> authController.login(admin));
		
	    
	}
	
	@Test()
	
	 void loginTestFailed3() throws InvalidAuthorizationException {

		Admin admin = new Admin("satyam", "satyam",null,null);
		UserDetails loadUserByUsername = custdetailservice.loadUserByUsername(admin.getUserid());
		UserDetails value = new User(admin.getUserid(), admin.getUpassword()+"wrong", new ArrayList<>());
		when(custdetailservice.loadUserByUsername(admin.getUserid())).thenReturn(value);
		when(jwtutil.generateToken(loadUserByUsername)).thenReturn("token");
		assertThrows(InvalidAuthorizationException.class,()-> authController.login(admin));
		
	    
	}
	
	
	@Test()
	
	 void loginTestFailed4() throws InvalidAuthorizationException {

		Admin admin = new Admin("shipa", "shilpa",null,null);
		UserDetails loadUserByUsername = custdetailservice.loadUserByUsername(admin.getUserid());
		UserDetails value = new User(admin.getUserid(), admin.getUpassword()+"wrong", new ArrayList<>());
		when(custdetailservice.loadUserByUsername(admin.getUserid())).thenReturn(value);
		when(jwtutil.generateToken(loadUserByUsername)).thenReturn("token");
		assertThrows(InvalidAuthorizationException.class,()-> authController.login(admin));
		
	    
	}
	@Test
	 void validateTestValidtoken() {

		
		when(jwtutil.validateToken("token")).thenReturn(true);
		when(jwtutil.extractUsername("token")).thenReturn("geeta");
		Admin admin = new Admin("geeta", "geeta", "geeta",null);
		Optional<Admin> data = Optional.of(admin);
		when(userservice.findById("geeta")).thenReturn(data);
		ResponseEntity<?> validity = authController.getValidity("bearer token");
		assertEquals( true, validity.getBody().toString().contains("true"));

	}
	@Test
	 void validateTestValidtoken2() {

		
		when(jwtutil.validateToken("token")).thenReturn(true);
		when(jwtutil.extractUsername("token")).thenReturn("sabhya");
		Admin admin = new Admin("sabhya", "sabhya", "sabhya",null);
		Optional<Admin> data = Optional.of(admin);
		when(userservice.findById("sabhya")).thenReturn(data);
		ResponseEntity<?> validity = authController.getValidity("bearer token");
		assertEquals( true, validity.getBody().toString().contains("true"));

	}

	@Test
	 void validateTestValidtoken3() {

		
		when(jwtutil.validateToken("token")).thenReturn(true);
		when(jwtutil.extractUsername("token")).thenReturn("satyam");
		Admin admin = new Admin("satyam", "satyam", "satyam",null);
		Optional<Admin> data = Optional.of(admin);
		when(userservice.findById("satyam")).thenReturn(data);
		ResponseEntity<?> validity = authController.getValidity("bearer token");
		assertEquals( true, validity.getBody().toString().contains("true"));

	}
	@Test
	 void validateTestValidtoken4() {

		
		when(jwtutil.validateToken("token")).thenReturn(true);
		when(jwtutil.extractUsername("token")).thenReturn("shilpa");
		Admin admin = new Admin("shilpa", "shilpa", "shilpa",null);
		Optional<Admin> data = Optional.of(admin);
		when(userservice.findById("shilpa")).thenReturn(data);
		ResponseEntity<?> validity = authController.getValidity("bearer token");
		assertEquals( true, validity.getBody().toString().contains("true"));

	}
	@Test
	 void validateTestInValidtoken() {

		
		when(jwtutil.validateToken("token")).thenReturn(false);
		ResponseEntity<?> validity = authController.getValidity("bearer token");
		assertEquals( true, validity.getBody().toString().contains("false"));
	}
}