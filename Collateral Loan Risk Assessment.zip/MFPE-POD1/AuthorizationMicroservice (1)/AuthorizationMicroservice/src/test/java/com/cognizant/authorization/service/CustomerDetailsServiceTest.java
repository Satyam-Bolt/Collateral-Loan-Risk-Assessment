package com.cognizant.authorization.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.userdetails.UserDetails;

import com.cognizant.authorization.model.Admin;
import com.cognizant.authorization.repository.UserRepository;
import com.cognizant.authorization.service.CustomerDetailsService;

@SpringBootTest
public class CustomerDetailsServiceTest {
	
	UserDetails userDetails;
	
	@InjectMocks
	CustomerDetailsService customerDetailsService;
	
	@Mock
	UserRepository userservice;


	
	@Test
	 void loadUserByUsernameTest() {
		
		Admin user=new Admin("geeta","geeta","geeta",null);
		Optional<Admin> data =Optional.of(user) ;
		when(userservice.findById("geeta")).thenReturn(data);
		UserDetails loadUserByUsername = customerDetailsService.loadUserByUsername("geeta");
		assertEquals(user.getUserid(),loadUserByUsername.getUsername());
	}
	
	@Test
	 void loadUserByUsernameTest2() {
		
		Admin user=new Admin("sabhya","sabhya","sabhya",null);
		Optional<Admin> data =Optional.of(user) ;
		when(userservice.findById("sabhya")).thenReturn(data);
		UserDetails loadUserByUsername = customerDetailsService.loadUserByUsername("sabhya");
		assertEquals(user.getUserid(),loadUserByUsername.getUsername());
	}
	
	@Test
	 void loadUserByUsernameTest3() {
		
		Admin user=new Admin("shilpa","shilpa","shilpa",null);
		Optional<Admin> data =Optional.of(user) ;
		when(userservice.findById("shilpa")).thenReturn(data);
		UserDetails loadUserByUsername = customerDetailsService.loadUserByUsername("shilpa");
		assertEquals(user.getUserid(),loadUserByUsername.getUsername());
	}
	
	@Test
	 void loadUserByUsernameTest4() {
		
		Admin user=new Admin("satyam","satyam","satyam",null);
		Optional<Admin> data =Optional.of(user) ;
		when(userservice.findById("satyam")).thenReturn(data);
		UserDetails loadUserByUsername = customerDetailsService.loadUserByUsername("satyam");
		assertEquals(user.getUserid(),loadUserByUsername.getUsername());
	}
	
	
	@Test
	 void loadUserByUsernameFalseTest1() {
		
		Admin user=new Admin("geeta","geeta","geeta",null);
		Optional<Admin> data =Optional.of(user) ;
		when(userservice.findById("geeta")).thenReturn(data);
		UserDetails loadUserByUsername = customerDetailsService.loadUserByUsername(user.getUserid());
		assertNotNull(loadUserByUsername.getUsername());
	}
	
	@Test
	 void loadUserByUsernameFalseTest2() {
		
		Admin user=new Admin("sabhya","sabhya","sabhya",null);
		Optional<Admin> data =Optional.of(user) ;
		when(userservice.findById("sabhya")).thenReturn(data);
		UserDetails loadUserByUsername = customerDetailsService.loadUserByUsername(user.getUserid());
		assertNotEquals(user.getUserid()+"false",loadUserByUsername.getUsername());
	}

	@Test
	 void loadUserByUsernameFalseTest3() {
		
		Admin user=new Admin("satyam","satyam","satyam",null);
		Optional<Admin> data =Optional.of(user) ;
		when(userservice.findById("satyam")).thenReturn(data);
		UserDetails loadUserByUsername = customerDetailsService.loadUserByUsername(user.getUserid());
		assertNotEquals(user.getUserid()+"false",loadUserByUsername.getUsername());
	}
	
	@Test
	 void loadUserByUsernameFalseTest4() {
		
		Admin user=new Admin("shilpa","shilpa","shilpa",null);
		Optional<Admin> data =Optional.of(user) ;
		when(userservice.findById("shilpa")).thenReturn(data);
		UserDetails loadUserByUsername = customerDetailsService.loadUserByUsername(user.getUserid());
		assertNotEquals(user.getUserid()+"false",loadUserByUsername.getUsername());
	}

}