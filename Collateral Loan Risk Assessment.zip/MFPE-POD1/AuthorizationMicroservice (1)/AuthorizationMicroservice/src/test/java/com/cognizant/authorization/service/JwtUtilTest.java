package com.cognizant.authorization.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import com.cognizant.authorization.repository.UserRepository;
import com.cognizant.authorization.service.CustomerDetailsService;
import com.cognizant.authorization.service.JwtUtil;


@SpringBootTest
class JwtUtilTest {
	
	@Mock
	UserDetails userdetails;

	@InjectMocks
	JwtUtil jwtUtil;

	@Mock
	JwtUtil jwt;
	
	@Mock
	UserRepository userservice;
	
	@Mock
	CustomerDetailsService customerDetailsService;


	@Test
	 void generateTokenTest() {
		userdetails = new User("geeta", "geeta", new ArrayList<>());
		String generateToken = jwtUtil.generateToken(userdetails);
		assertNotNull(generateToken);
	}
	
	@Test
	 void generateTokenTest2() {
		userdetails = new User("sabhya", "sabhya", new ArrayList<>());
		String generateToken = jwtUtil.generateToken(userdetails);
		assertNotNull(generateToken);
	}
	
	@Test
	 void generateTokenTest3() {
		userdetails = new User("satyam", "satyam", new ArrayList<>());
		String generateToken = jwtUtil.generateToken(userdetails);
		assertNotNull(generateToken);
	}
	
	@Test
	 void generateTokenTest4() {
		userdetails = new User("shilpa", "shilpa", new ArrayList<>());
		String generateToken = jwtUtil.generateToken(userdetails);
		assertNotNull(generateToken);
	}
	
	
	@Test
	 void validateTokenTest() {
		userdetails = new User("geeta", "geeta", new ArrayList<>());
		String generateToken = jwtUtil.generateToken(userdetails);
		Boolean validateToken = jwtUtil.validateToken(generateToken);
		assertEquals(true, validateToken);
	}
	@Test
	 void validateTokenTest2() {
		userdetails = new User("sabhya", "sabhya", new ArrayList<>());
		String generateToken = jwtUtil.generateToken(userdetails);
		Boolean validateToken = jwtUtil.validateToken(generateToken);
		assertTrue( validateToken);
	}
	
	@Test
	 void validateTokenTest3() {
		userdetails = new User("satyam", "satyam", new ArrayList<>());
		String generateToken = jwtUtil.generateToken(userdetails);
		Boolean validateToken = jwtUtil.validateToken(generateToken);
		assertTrue( validateToken);
	}
	
	@Test
	 void validateTokenTest4() {
		userdetails = new User("shilpa", "shilpa", new ArrayList<>());
		String generateToken = jwtUtil.generateToken(userdetails);
		Boolean validateToken = jwtUtil.validateToken(generateToken);
		assertTrue( validateToken);
	}
	
	@Test
	 void validateTokenNegativeTest() {
		userdetails = new User("geeta", "geeta", new ArrayList<>());
		String generateToken = jwtUtil.generateToken(userdetails);
		Boolean validateToken = jwtUtil.validateToken(generateToken+"gh");
		assertFalse(validateToken);
	}

	@Test
	 void validateTokenNegativeTest2() {
		userdetails = new User("sabhya", "sabhya", new ArrayList<>());
		String generateToken = jwtUtil.generateToken(userdetails);
		Boolean validateToken = jwtUtil.validateToken(generateToken+"gh");
		assertEquals(false,validateToken);
	}


	@Test
	 void validateTokenNegativeTest3() {
		userdetails = new User("satyam", "satyam", new ArrayList<>());
		String generateToken = jwtUtil.generateToken(userdetails);
		Boolean validateToken = jwtUtil.validateToken(generateToken+"gh");
		assertEquals(false,validateToken);
	}

	@Test
	 void validateTokenNegativeTest4() {
		userdetails = new User("shilpa", "shilpa", new ArrayList<>());
		String generateToken = jwtUtil.generateToken(userdetails);
		Boolean validateToken = jwtUtil.validateToken(generateToken+"gh");
		assertEquals(false,validateToken);
	}

	

}