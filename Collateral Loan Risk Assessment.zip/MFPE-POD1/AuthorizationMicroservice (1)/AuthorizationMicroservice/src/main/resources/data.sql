insert into user (userid,upassword,uname) values ('geeta','geeta','geeta');
insert into user (userid,upassword,uname) values ('shilpa','shilpa','shilpa');
insert into user (userid,upassword,uname) values ('sabhya','sabhya','sabhya');
insert into user (userid,upassword,uname) values ('satyam','satyam','satyam');