package com.cognizant.authorization.exception;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.cognizant.authorization.model.MessageResponse;

import lombok.extern.slf4j.Slf4j;

/**Service class*/
@Slf4j
@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice
public class GlobalExceptionHandler  extends ResponseEntityExceptionHandler {
	
	/**
	 * 
	 * @param ex
	 * @return
	 */
	@ResponseStatus(HttpStatus.UNAUTHORIZED)
	@ExceptionHandler(InvalidAuthorizationException.class)
	public ResponseEntity<Object> handleInvalidAuthorizationExceptions(InvalidAuthorizationException ex) {

		log.error("Invalid Credentials......");
		return ResponseEntity.badRequest().body(new MessageResponse("Invalid Credentials......"));
	}
	
	/**
	 * @param ex
	 * @return
	 */
	@ResponseStatus(HttpStatus.UNAUTHORIZED)
	@ExceptionHandler(UsernameNotFoundException.class)
	public ResponseEntity<Object> usernameNotFoundExceptions(UsernameNotFoundException ex) {

		log.error("UserId is not found....");
		return ResponseEntity.badRequest().body(new MessageResponse("UserId is not found...."));
	}
	
	
	
}
