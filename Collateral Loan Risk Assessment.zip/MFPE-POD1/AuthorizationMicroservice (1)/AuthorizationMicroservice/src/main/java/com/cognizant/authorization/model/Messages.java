package com.cognizant.authorization.model;

public enum Messages {
	LOGIN("Login"),
	INVALIDTOKEN("Invalid Token....."),
	INVALIDUSERID("UserId is not found...."),
	INVALIDCREDENTIALS("Invalid Credentials");
	private String message;
	public String getMessage() {
		return message;
	}
	private Messages(String message) {
		this.message = message;
	}
}
