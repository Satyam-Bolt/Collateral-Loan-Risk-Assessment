package com.cognizant.authorization.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cognizant.authorization.model.Admin;
import com.cognizant.authorization.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CustomerDetailsService implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private JwtUtil jwtutil;

	@Override
	public UserDetails loadUserByUsername(String uid) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		log.debug("Start : {}", "loadUserByUsername");
		Optional<Admin> user = userRepository.findById(uid);
		
		

		log.debug("End : {}", "loadUserByUsername");
		
		if(user.isPresent()) {
			Admin custuser=user.get();
		return new User(custuser.getUserid(), custuser.getUpassword(), new ArrayList<>());
		}
		else {
			throw new UsernameNotFoundException("Cannot find User ");
			
		}
		
		
	}
	
	public String getUserName(String token) {
		return userRepository.findById(jwtutil.extractUsername(token)).orElse(null).getUname();
	}

}
