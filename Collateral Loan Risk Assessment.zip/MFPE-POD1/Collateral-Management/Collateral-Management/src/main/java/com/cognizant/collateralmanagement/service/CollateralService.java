package com.cognizant.collateralmanagement.service;

import com.cognizant.collateralmanagement.exception.CollateralNotFoundException;
import com.cognizant.collateralmanagement.exception.DataNotPresentException;
import com.cognizant.collateralmanagement.model.CollateralCashDeposits;
import com.cognizant.collateralmanagement.model.CollateralRealEstate;


public interface CollateralService {

	CollateralRealEstate getCollateralRealEstate(int loanId) throws  CollateralNotFoundException;

	 
	CollateralRealEstate saveCollateralForRealEstate(CollateralRealEstate realEstate) throws DataNotPresentException;


	CollateralCashDeposits getCollateralCashDeposits(int loanId) throws CollateralNotFoundException;


	CollateralCashDeposits saveCollateralCashDeposits(CollateralCashDeposits cashDeposits) throws DataNotPresentException;

	
	
	
	
}
