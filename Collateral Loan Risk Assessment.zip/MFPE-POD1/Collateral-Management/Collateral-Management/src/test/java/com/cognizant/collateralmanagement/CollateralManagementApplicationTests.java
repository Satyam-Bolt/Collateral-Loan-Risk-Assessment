package com.cognizant.collateralmanagement;



import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class CollateralManagementApplicationTests{
		@Test
		void contextLoads() {
		}

}
