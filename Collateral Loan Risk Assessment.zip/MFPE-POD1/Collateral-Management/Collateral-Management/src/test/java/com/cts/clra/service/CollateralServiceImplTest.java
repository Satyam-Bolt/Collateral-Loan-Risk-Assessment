package com.cts.clra.service;

import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cognizant.collateralmanagement.exception.CollateralNotFoundException;
import com.cognizant.collateralmanagement.exception.DataNotPresentException;
import com.cognizant.collateralmanagement.model.CollateralCashDeposits;
import com.cognizant.collateralmanagement.model.CollateralRealEstate;
import com.cognizant.collateralmanagement.repository.CollateralCashDepositsRepository;
import com.cognizant.collateralmanagement.repository.CollateralRealEstateRepository;
import com.cognizant.collateralmanagement.service.CollateralServiceImpl;

@ExtendWith(MockitoExtension.class)
public class CollateralServiceImplTest {
	@Mock
	private CollateralCashDepositsRepository collateralCashDepositRepo;
	@Mock
	private CollateralRealEstateRepository collateralRealEstateRepo;
	@InjectMocks
	private CollateralServiceImpl collateralServiceImpl;
	@Test
	void testgetCollateralRealEstate_1() throws CollateralNotFoundException {
		
		
		CollateralRealEstate collateralRealEstate=new CollateralRealEstate(1,1,"diya","20-14","lucknow","Uttar Pradesh", 500);
		when(collateralRealEstateRepo.findById(1)).thenReturn(Optional.of(collateralRealEstate));
		assertEquals(1,collateralServiceImpl.getCollateralRealEstate(1).getLoanId());
	}
	@Test
    void testgetCollateralRealEstate_2() throws CollateralNotFoundException {
		
		
		CollateralRealEstate collateralRealEstate=new CollateralRealEstate(1,1,"diya","20-14","lucknow","Uttar Pradesh", 500);
		when(collateralRealEstateRepo.findById(1)).thenReturn(Optional.of(collateralRealEstate));
		assertNotEquals(2,collateralServiceImpl.getCollateralRealEstate(1).getLoanId());
	}
	@Test
    void testgetCollateralRealEstate_3() throws CollateralNotFoundException {
		
		
		CollateralRealEstate collateralRealEstate=new CollateralRealEstate(1,1,"diya","20-14","lucknow","Uttar Pradesh", 500);
		when(collateralRealEstateRepo.findById(1)).thenReturn(Optional.of(collateralRealEstate));
		assertEquals("lucknow",collateralServiceImpl.getCollateralRealEstate(1).getCity());
		
	}
	@Test
    void testgetCollateralRealEstate_4() throws CollateralNotFoundException {
		
		
		CollateralRealEstate collateralRealEstate=new CollateralRealEstate(1,1,"diya","20-14","lucknow","Uttar Pradesh", 500);
		when(collateralRealEstateRepo.findById(1)).thenReturn(Optional.of(collateralRealEstate));
		assertNotEquals("lucknow ",collateralServiceImpl.getCollateralRealEstate(1).getCity());
		
	}
	@Test
    void testgetCollateralRealEstate_5() throws DataNotPresentException,CollateralNotFoundException {
		
		
		CollateralRealEstate collateralRealEstate=new CollateralRealEstate(1,1,"diya","20-14","lucknow","Uttar Pradesh", 500);
		when(collateralRealEstateRepo.findById(1)).thenReturn(Optional.of(collateralRealEstate));
		assertEquals(500,collateralServiceImpl.getCollateralRealEstate(1).getAreaInFt());
	}
	@Test
    void testgetCollateralRealEstate_6() throws DataNotPresentException,CollateralNotFoundException {
		
		
		CollateralRealEstate collateralRealEstate=new CollateralRealEstate(1,1,"diya","20-14","lucknow","Uttar Pradesh", 500);
		when(collateralRealEstateRepo.findById(1)).thenReturn(Optional.of(collateralRealEstate));
		assertNotEquals(250,collateralServiceImpl.getCollateralRealEstate(1).getAreaInFt());
	}
	@Test
	void testsaveCollateralForRealEstate_1() throws  CollateralNotFoundException, DataNotPresentException{
		
		CollateralRealEstate collateralRealEstate=new CollateralRealEstate(1,1,"seetha","19-52","Bhopal","Madhya Pradesh", 250);
		when(collateralRealEstateRepo.save(collateralRealEstate)).thenReturn(collateralRealEstate);
		assertEquals(1,collateralServiceImpl.saveCollateralForRealEstate(collateralRealEstate).getLoanId());
	}
	@Test
	void testsaveCollateralForRealEstate_2() throws  CollateralNotFoundException, DataNotPresentException{
		
		CollateralRealEstate collateralRealEstate=new CollateralRealEstate(1,1,"seetha","19-52","Bhopal","Madhya Pradesh", 250);
		when(collateralRealEstateRepo.save(collateralRealEstate)).thenReturn(collateralRealEstate);
		assertNotEquals(2,collateralServiceImpl.saveCollateralForRealEstate(collateralRealEstate).getLoanId());
	}
	@Test
	void testsaveCollateralForRealEstate_3() throws  CollateralNotFoundException, DataNotPresentException{
		
		CollateralRealEstate collateralRealEstate=new CollateralRealEstate(1,1,"seetha","19-52","Bhopal","Madhya Pradesh", 250);
		when(collateralRealEstateRepo.save(collateralRealEstate)).thenReturn(collateralRealEstate);
		assertEquals(250,collateralServiceImpl.saveCollateralForRealEstate(collateralRealEstate).getAreaInFt());
	}
	@Test
	void testsaveCollateralForRealEstate_4() throws  CollateralNotFoundException, DataNotPresentException{
		
		CollateralRealEstate collateralRealEstate=new CollateralRealEstate(1,1,"seetha","19-52","Bhopal","Madhya Pradesh", 250);
		when(collateralRealEstateRepo.save(collateralRealEstate)).thenReturn(collateralRealEstate);
		assertNotEquals(500,collateralServiceImpl.saveCollateralForRealEstate(collateralRealEstate).getAreaInFt());
	}
	@Test
	void testsaveCollateralForRealEstate_5() throws  CollateralNotFoundException, DataNotPresentException{
		
		CollateralRealEstate collateralRealEstate=new CollateralRealEstate(1,1,"seetha","19-52","Bhopal","Madhya Pradesh", 250);
		when(collateralRealEstateRepo.save(collateralRealEstate)).thenReturn(collateralRealEstate);
		assertEquals(250,collateralServiceImpl.saveCollateralForRealEstate(collateralRealEstate).getAreaInFt());
		assertNotEquals(500,collateralServiceImpl.saveCollateralForRealEstate(collateralRealEstate).getAreaInFt());
	}
	@Test
	void testsaveCollateralForRealEstate_6() throws  CollateralNotFoundException, DataNotPresentException{
		
		CollateralRealEstate collateralRealEstate=new CollateralRealEstate(1,1,"seetha","19-52","Bhopal","Madhya Pradesh", 250);
		when(collateralRealEstateRepo.save(collateralRealEstate)).thenReturn(collateralRealEstate);
		assertEquals("seetha",collateralServiceImpl.saveCollateralForRealEstate(collateralRealEstate).getOwnerName());
		
	}
	@Test
	void testgetCollateralCashDeposits_1() throws CollateralNotFoundException {
		
		
		CollateralCashDeposits collateralCashDeposits=new CollateralCashDeposits(1,1,"diya","SBI",789452457,50000.0,4.0);
		when(collateralCashDepositRepo.findById(1)).thenReturn(Optional.of(collateralCashDeposits));
		assertEquals(1,collateralServiceImpl.getCollateralCashDeposits(1).getLoanId());
	}
	@Test
	void testgetCollateralCashDeposits_2() throws CollateralNotFoundException {
		
		
		CollateralCashDeposits collateralCashDeposits=new CollateralCashDeposits(1,1,"diya","SBI",789452457,50000.0,4.0);
		when(collateralCashDepositRepo.findById(1)).thenReturn(Optional.of(collateralCashDeposits));
		assertNotEquals(2,collateralServiceImpl.getCollateralCashDeposits(1).getLoanId());
	}
	@Test
	void testgetCollateralCashDeposits_3() throws CollateralNotFoundException {
		
		
		CollateralCashDeposits collateralCashDeposits=new CollateralCashDeposits(1,1,"diya","SBI",789452457,50000.0,4.0);
		when(collateralCashDepositRepo.findById(1)).thenReturn(Optional.of(collateralCashDeposits));
		assertEquals("SBI",collateralServiceImpl.getCollateralCashDeposits(1).getBankName());
		
	}
	@Test
	void testgetCollateralCashDeposits_4() throws CollateralNotFoundException {
		
		
		CollateralCashDeposits collateralCashDeposits=new CollateralCashDeposits(1,1,"diya","SBI",789452457,50000.0,4.0);
		when(collateralCashDepositRepo.findById(1)).thenReturn(Optional.of(collateralCashDeposits));
		assertEquals(50000,collateralServiceImpl.getCollateralCashDeposits(1).getDepositAmount());
		
	}
	@Test
	void testgetCollateralCashDeposits_5() throws CollateralNotFoundException {
		
		
		CollateralCashDeposits collateralCashDeposits=new CollateralCashDeposits(1,1,"diya","SBI",789452457,50000.0,4.0);
		when(collateralCashDepositRepo.findById(1)).thenReturn(Optional.of(collateralCashDeposits));
		assertEquals(789452457,collateralServiceImpl.getCollateralCashDeposits(1).getAccountNumber());
		
	}
	@Test
	void testgetCollateralCashDeposits_6() throws CollateralNotFoundException {
		
		
		CollateralCashDeposits collateralCashDeposits=new CollateralCashDeposits(1,1,"diya","SBI",789452457,50000.0,4.0);
		when(collateralCashDepositRepo.findById(1)).thenReturn(Optional.of(collateralCashDeposits));
		assertNotEquals(78945245,collateralServiceImpl.getCollateralCashDeposits(1).getAccountNumber());
		
	}
	@Test
	void testsaveCollateralCashDeposits_1() throws  CollateralNotFoundException, DataNotPresentException{
		
		CollateralCashDeposits collateralCashDeposits=new CollateralCashDeposits(1,1,"diya","SBI",789452457,50000.0,4.0);
		when(collateralCashDepositRepo.save(collateralCashDeposits)).thenReturn(collateralCashDeposits);
		assertEquals(1,collateralServiceImpl.saveCollateralCashDeposits(collateralCashDeposits).getLoanId());	
	}
	@Test
	void testsaveCollateralCashDeposits_2() throws  CollateralNotFoundException, DataNotPresentException{
		
		CollateralCashDeposits collateralCashDeposits=new CollateralCashDeposits(1,1,"diya","SBI",789452457,50000.0,4.0);
		when(collateralCashDepositRepo.save(collateralCashDeposits)).thenReturn(collateralCashDeposits);
		assertNotEquals(2,collateralServiceImpl.saveCollateralCashDeposits(collateralCashDeposits).getLoanId());	
	}
	@Test
	void testsaveCollateralCashDeposits_3() throws  CollateralNotFoundException, DataNotPresentException{
		
		CollateralCashDeposits collateralCashDeposits=new CollateralCashDeposits(1,1,"diya","SBI",789452457,50000.0,4.0);
		when(collateralCashDepositRepo.save(collateralCashDeposits)).thenReturn(collateralCashDeposits);
		assertEquals(4.0,collateralServiceImpl.saveCollateralCashDeposits(collateralCashDeposits).getLockPeriod());	
	}
	@Test
	void testsaveCollateralCashDeposits_4() throws  CollateralNotFoundException, DataNotPresentException{
		
		CollateralCashDeposits collateralCashDeposits=new CollateralCashDeposits(1,1,"diya","SBI",789452457,50000.0,4.0);
		when(collateralCashDepositRepo.save(collateralCashDeposits)).thenReturn(collateralCashDeposits);
		assertNotEquals(5,collateralServiceImpl.saveCollateralCashDeposits(collateralCashDeposits).getLockPeriod());	
	}
	@Test
	void testsaveCollateralCashDeposits_5() throws  CollateralNotFoundException, DataNotPresentException{
		
		CollateralCashDeposits collateralCashDeposits=new CollateralCashDeposits(1,1,"diya","SBI",789452457,50000.0,4.0);
		when(collateralCashDepositRepo.save(collateralCashDeposits)).thenReturn(collateralCashDeposits);
		assertNotEquals(50000,collateralServiceImpl.saveCollateralCashDeposits(collateralCashDeposits).getDepositAmount());	
	}
	@Test
	void testsaveCollateralCashDeposits_6() throws  CollateralNotFoundException, DataNotPresentException{
		
		CollateralCashDeposits collateralCashDeposits=new CollateralCashDeposits(1,1,"diya","SBI",789452457,50000.0,4.0);
		when(collateralCashDepositRepo.save(collateralCashDeposits)).thenReturn(collateralCashDeposits);
		assertEquals("diya",collateralServiceImpl.saveCollateralCashDeposits(collateralCashDeposits).getOwnerName());	
	}
	
	

	
}