package com.cognizant.collateralmanagement.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;

import com.cognizant.collateralmanagement.client.AuthClient;
import com.cognizant.collateralmanagement.model.AuthResponse;
import com.cognizant.collateralmanagement.model.CollateralRealEstate;
import com.cognizant.collateralmanagement.repository.CollateralCashDepositsRepository;
import com.cognizant.collateralmanagement.repository.CollateralRealEstateRepository;
import com.cognizant.collateralmanagement.service.CollateralService;

import lombok.extern.slf4j.Slf4j;

@AutoConfigureMockMvc
@SpringBootTest
@Slf4j
public class CollateralControllerTest {
	
	@InjectMocks
	
	private CollateralController collateralController;
	@Mock
	private CollateralController cc;
	
	@Mock
	private CollateralService collateralService;
	
	@Mock
	CollateralCashDepositsRepository collateralCashDepositsRepository;
	
	@Mock
	CollateralRealEstateRepository collateralRealEstateRepository;
	
	@Mock
	private AuthClient authClient;
	
	@Autowired
	private MockMvc mockMvc;
	
	@Test
	public void getCollateralRealEstateTest() throws Exception
	{
		AuthResponse authResponse=new AuthResponse("geeta","geeta",true);
		ResponseEntity<AuthResponse> response = new ResponseEntity<AuthResponse>(authResponse, HttpStatus.OK);

		CollateralRealEstate collateralRealEstate=new CollateralRealEstate(3,3,"diya","20-14","lucknow","Uttar Pradesh", 500);
		Optional<CollateralRealEstate> optional=Optional.of(collateralRealEstate);
		ResponseEntity<CollateralRealEstate> responseEntity = new ResponseEntity<>(collateralRealEstate, HttpStatus.OK);
		when(authClient.verifyToken("Bearer Token")).thenReturn(authResponse);
		//when(collateralService.getCollateralRealEstate( 1)).thenReturn(collateralRealEstate);

		
		
		//when(collateralController.getCollateralRealEstate("Bearer Token", 1)).thenReturn(responseEntity);
		
		doReturn(responseEntity).when(cc).getCollateralRealEstate("Bearer Token", 3);

		MvcResult result = mockMvc.perform(get("/getCollaterals/realEstate/3").header("Authorization", "Bearer Token"))
				.andReturn();
		//String actual = result.getResponse().getContentAsString().substring(18, 19);
		int status = result.getResponse().getStatus();
		//log.info(status);
		assertEquals(Integer.toString(optional.get().getLoanId()), status);
		


		
	}

}